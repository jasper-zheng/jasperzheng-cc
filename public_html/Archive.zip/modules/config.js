// let linkPrefix = "http://127.0.0.1:3000/";
let linkPrefix = "https://alaskawinter.cc/";
let widthThreshold = 800

let version = '260'

export {linkPrefix,widthThreshold,version}
